﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class StringExtension
{
    public static string toJavaString(this string str)
    {
        return str;
    }

    public static string showAsToast(this string str)
    {
        return str;
    }
}
